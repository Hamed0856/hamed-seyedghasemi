</section>
						</section>
				</section>
				<footer class="divTable">
						<section class="divTableRow">
							<article class="divTableCell">مالكيت مادي و معنوي سايت</article>
						</section>
				</footer>
			</div>
		</div>
</div>


</body>

</html>