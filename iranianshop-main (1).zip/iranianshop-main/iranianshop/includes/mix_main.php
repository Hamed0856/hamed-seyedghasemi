<html>
<head>
<meta charset="UTF-8" />
<title>فروشگاه ايرانيان</title>


<style type="text/css">
<!--
	.set_style_link {
     text-decoration: none;
     font-weight: bold; 
     }
    -->
</style>

</head>

<body>

<table dir="rtl"  style="font-family: tahoma;font-size: 13pt;width: 1024px;margin-left: auto;margin-right: auto;"   >

    <tr>
        <td>
        
            <table style="width: 100%;"  border="1"  >
                <tr>
	               <td>لوگوي سايت</td>
                </tr>
            </table>

            <table style="width: 100%;"  border="1"  >
                <tr style="text-align: center;">
                    <td><a href="index.php" class="set_style_link" >صفحه اصلي</a></td>
                    <td><a href="#"  class="set_style_link" >عضويت در سايت</a></td>
                    <td><a href="#"  class="set_style_link" >ورود به سايت</a></td>
                    <td><a href="#"  class="set_style_link" >درباره ما</a></td>
                    <td><a href="#"  class="set_style_link" >ارتباط با ما</a></td>
                </tr>
            </table>

            <table style="width: 100%;"  border="1"  >
                <tr>
                    <td style="width: 25%;">بخش امكانات سايت</td>
                    <td style="width: 75%;">
                    محصولات
                    </td>
                </tr>
            </table>

            <table style="width: 100%;"  border="1"  >
                <tr>
                	<td>مالكيت مادي و معنوي سايت</td>
                </tr>
            </table>

        </td>
    </tr>
</table>


</body>

</html>