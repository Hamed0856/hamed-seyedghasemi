<html>
<head>
<meta charset="UTF-8" />
<title>فروشگاه ايرانيان</title>


<style type="text/css">
<!--
	.set_style_link {
     text-decoration: none;
     font-weight: bold; 
     }
     
     li{
        display: inline;
        padding: inherit;
     }
     
    -->
</style>

</head>

<body>

<div dir="rtl"  style="font-family: tahoma;font-size: 13pt;width: 1024px;margin-left: auto;margin-right: auto;"    >


          <header>
                <nav style="width: 100%;" >
                  <ul>
                       <li>
                         <a href="index.php" class="set_style_link" >صفحه اصلي</a>
                       </li>  
                                             
                       <li>
                        <a href="#"  class="set_style_link" >عضويت در سايت</a>
                       </li> 
                        
                       <li>
                        <a href="#"  class="set_style_link" >ورود به سايت</a>
                       </li> 
                      
                       <li>
                        <a href="#"  class="set_style_link" >درباره ما</a>
                       </li> 
                       
                       <li>
                        <a href="#"  class="set_style_link" >ارتباط با ما</a>
                       </li> 
                        
                  </ul>      
                </nav>
          </header>
          
            <div> 
                    <aside style="width: 100%;">
                    
                        <section style="width: 25%;float: right;">
                             <article>بخش امكانات سايت</article>
                             <article>بخش امكانات سايت</article>
                             <article>بخش امكانات سايت</article>
                             <article>بخش امكانات سايت</article>
                        </section>
                        
                        <section  style="width: 75%;float: left;">
                             <article>محصولات</article>
                            <article>محصولات</article>
                            <article>محصولات</article>
                            <article>محصولات</article>
                            <article>محصولات</article>
                            <article>محصولات</article>
                            <article>محصولات</article>
                            <article>محصولات</article>
                        </section>
                        
                    </aside>
 
           </div>

            <div> 
                             <footer style="float: bottom;">
                                	 مالكيت مادي و معنوي سايت 
                            </footer>
           </div>
                   

</div>



</body>

</html>