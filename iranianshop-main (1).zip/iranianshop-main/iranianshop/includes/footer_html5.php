</td>
                </tr>
            </table>

            <table style="width: 100%;"  border="1"  >
                <tr>
                	<td>مالكيت مادي و معنوي سايت</td>
                </tr>
            </table>

        </td>
    </tr>
</table>


</body>

</html>