					               </div>
                    	</div>
					</div>
				</div>
				<div class="divTable" >
					<div class="divTableBody">
						<div class="divTableRow" >
							<div class="divTableCell" >مالكيت مادي و معنوي سايت</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>


</body>

</html>